/***
 * Gustavo Shinji Inoue 6878758
 * Wu Yuexiang 6792502
 ***/

/***
 * How to use:
 * Definir tamanho do vetor a ser gerado pela função
 * rand() em #define SIZE TAMANHO_DO_VETOR e rodar
 ***/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/syscall.h>
#define SIZE 100

int main (void)
{
    int v[SIZE], i;

    srand(time(NULL));
    for (i = 0; i < SIZE; i++)
        v[i] = rand() % (SIZE * (rand() % 10 + 1)) + 1;
    printf ("v = rand()\n");
    for (i = 0; i < SIZE; i++)
        printf ("%d ", v[i]);
    printf ("\n");    
    syscall(347, v, SIZE);
    printf ("v = syscall()\n");    
    for (i = 0; i < SIZE; i++)
        printf ("%d ", v[i]);
    printf ("\n");
    return 0;
}
