#include <linux/linkage.h>

void swap (int *a, int *b)
{
	int t;
	t = *a;
	*a = *b;
	*b = t;
}

void quicksort (int v[], int inicio, int fim)
{
    int p_esq, p_dir, pivo;

    p_esq = inicio;
    p_dir = fim;
    pivo = v[(inicio + fim) / 2];
    do
    {
        while (v[p_esq] < pivo)
            p_esq++;
        while (v[p_dir] > pivo)
            p_dir--;
        if (p_esq <= p_dir)
        {
            swap (&v[p_esq], &v[p_dir]);
            p_esq++;
            p_dir--;
        }
    } while (p_esq <= p_dir);
    if (p_dir > inicio)
        quicksort (v, inicio, p_dir);
    if (p_esq < fim)
        quicksort (v, p_esq, fim);
}

asmlinkage long sys_quicksort (int v[], int size)
{
	if (size <= 1)
        return;
	quicksort (v, 0, size - 1);
}
