/***
 * Gustavo Shinji Inoue 6878758
 * Wu Yuexiang 6792502
 ***/

/***
 * How to use:
 * Digitar vetor como argumento ao rodar o programa
 ***/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/syscall.h>

int main (int argc, char **argv)
{
    int *v, size, i;

    if (argc < 3)
    {
        printf("Deve-se conter pelo menos 2 argumentos.\n");
        exit(0);
    }
	v = (int *) malloc ((argc - 1) * sizeof(int));
    size = argc - 1;
    for (i = 0; i < argc - 1; i++)
        v[i] = atoi(argv[i + 1]);
    syscall(347, v, size);
    for (i = 0; i < argc - 1; i++)
        printf ("%d ", v[i]);
    printf ("\n");
    free(v);
    return 0;
}
