/***
 * Gustavo Shinji Inoue 6878758
 * Wu Yuexiang 
 ***/

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/stat.h>
#include <linux/moduleparam.h>

#define DRIVER_AUTHOR "Gustavo Shinji Inoue shinji@grad.icmc.usp.br | Wu Yuexiang wuyuexian@grad.icmc.usp.br"
#define DRIVER_DESC "Modulo do Quicksort"

static int v[10] = {386, 397, 970, 854, 265, 709, 551, 97, 371, 774};
static int arg_v = 10;

module_param_array (v, int, &arg_v, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP);
module_param (arg_v, int, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP);
MODULE_PARM_DESC (v, "vetor de inteiros");
MODULE_PARM_DESC (arg_v, "número de elementos do vetor");

void quicksort (int inicio, int fim)
{
    int p_esq, p_dir, pivo, aux;

    p_esq = inicio;
    p_dir = fim;
    pivo = v[(int)((inicio + fim) / 2)];
    do
    {
        while (v[p_esq] < pivo)
            p_esq++;
        while (v[p_dir] > pivo)
            p_dir--;
        if (p_esq <= p_dir)
        {
            aux = v[p_esq];
            v[p_esq] = v[p_dir];
            v[p_dir] = aux;
            p_esq++;
            p_dir--;
        }
    } while (p_esq <= p_dir);
    if (p_dir > inicio)
        quicksort (inicio, p_dir);
    if (p_esq < fim)
        quicksort (p_esq, fim);
}

int callQuicksort (void)
{
    if (arg_v <= 1)
        return 0;
	quicksort (0, arg_v - 1);
    return -1;
}

static int __init quicksort_init (void)
{
    int i;
    if (arg_v <= 1)
        return 0;
	callQuicksort ();
    for (i = 0; i < arg_v; i++)
        printk ("<1> %d ", v[i]);
    printk ("\n");
    return 0;
}

static void __exit quicksort_exit (void)
{
    printk ("C'est fini.");
}

module_init(quicksort_init);
module_exit(quicksort_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_SUPPORTED_DEVICE("testdevice");
